/**
 * Generated on Sat May 30 21:30:41 UTC 2020 by ObjGen 3.0
 */
package com.tpFinal;

/**
 *
 */
public class Aeropuerto {

   /** Property identificacion */
   String identificacion;

   /** Property ciudad */
   String ciudad;

   /** Property provincia */
   String provincia;

   /** Property pais */
   String pais;

   /** Property horaSalida */
   Date horaSalida;

   /** Property horaLlegada */
   Date horaLlegada;

   /**
    * Gets the identificacion
    */
   public String getIdentificacion() {
      return this.identificacion;
   }

   /**
    * Sets the identificacion
    */
   public void setIdentificacion(String value) {
      this.identificacion = value;
   }

   /**
    * Gets the ciudad
    */
   public String getCiudad() {
      return this.ciudad;
   }

   /**
    * Sets the ciudad
    */
   public void setCiudad(String value) {
      this.ciudad = value;
   }

   /**
    * Gets the provincia
    */
   public String getProvincia() {
      return this.provincia;
   }

   /**
    * Sets the provincia
    */
   public void setProvincia(String value) {
      this.provincia = value;
   }

   /**
    * Gets the pais
    */
   public String getPais() {
      return this.pais;
   }

   /**
    * Sets the pais
    */
   public void setPais(String value) {
      this.pais = value;
   }

   /**
    * Gets the horaSalida
    */
   public Date getHoraSalida() {
      return this.horaSalida;
   }

   /**
    * Sets the horaSalida
    */
   public void setHoraSalida(Date value) {
      this.horaSalida = value;
   }

   /**
    * Gets the horaLlegada
    */
   public Date getHoraLlegada() {
      return this.horaLlegada;
   }

   /**
    * Sets the horaLlegada
    */
   public void setHoraLlegada(Date value) {
      this.horaLlegada = value;
   }
}
