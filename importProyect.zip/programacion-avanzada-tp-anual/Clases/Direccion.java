/*
revisar provincias
*/
/**
 * Generated on Sat May 30 21:02:35 UTC 2020 by ObjGen 3.0
 */
package com.tpFinal;

/**
 *
 */
public class Direccion {

   /** Property calle */
   String calle;

   /** Property altura */
   String altura;

   /** Property provincia */
   Object provincia;

   /** Property ciudad */
   String ciudad;

   /** Property pais */
   String pais;

   /** Property codigoPostal */
   String codigoPostal;

   /**
    * Gets the calle
    */
   public String getCalle() {
      return this.calle;
   }

   /**
    * Sets the calle
    */
   public void setCalle(String value) {
      this.calle = value;
   }

   /**
    * Gets the altura
    */
   public String getAltura() {
      return this.altura;
   }

   /**
    * Sets the altura
    */
   public void setAltura(String value) {
      this.altura = value;
   }

   /**
    * Gets the provincia
    */
   public Object getProvincia() {
      return this.provincia;
   }

   /**
    * Sets the provincia
    */
   public void setProvincia(Object value) {
      this.provincia = value;
   }

   /**
    * Gets the ciudad
    */
   public String getCiudad() {
      return this.ciudad;
   }

   /**
    * Sets the ciudad
    */
   public void setCiudad(String value) {
      this.ciudad = value;
   }

   /**
    * Gets the pais
    */
   public String getPais() {
      return this.pais;
   }

   /**
    * Sets the pais
    */
   public void setPais(String value) {
      this.pais = value;
   }

   /**
    * Gets the codigoPostal
    */
   public String getCodigoPostal() {
      return this.codigoPostal;
   }

   /**
    * Sets the codigoPostal
    */
   public void setCodigoPostal(String value) {
      this.codigoPostal = value;
   }
}
