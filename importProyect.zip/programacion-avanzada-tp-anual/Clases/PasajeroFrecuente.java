/**
 * Generated on Sat May 30 20:28:30 UTC 2020 by ObjGen 3.0
 */
package com.tpFinal;

/**
 *
 */
public class PasajeroFrecuente {

   /** Property idPasajeroFrecuente */
   int idPasajeroFrecuente;

   /** Property numeroPasajero */
   int numeroPasajero;

   /** Property categoria */
   String categoria;

   /** Property alianza */
   String alianza;

   /** Property aerolinea */
   String aerolinea;

   /**
    * Gets the idPasajeroFrecuente
    */
   public int getIdPasajeroFrecuente() {
      return this.idPasajeroFrecuente;
   }

   /**
    * Sets the idPasajeroFrecuente
    */
   public void setIdPasajeroFrecuente(int value) {
      this.idPasajeroFrecuente = value;
   }

   /**
    * Gets the numeroPasajero
    */
   public int getNumeroPasajero() {
      return this.numeroPasajero;
   }

   /**
    * Sets the numeroPasajero
    */
   public void setNumeroPasajero(int value) {
      this.numeroPasajero = value;
   }

   /**
    * Gets the categoria
    */
   public String getCategoria() {
      return this.categoria;
   }

   /**
    * Sets the categoria
    */
   public void setCategoria(String value) {
      this.categoria = value;
   }

   /**
    * Gets the alianza
    */
   public String getAlianza() {
      return this.alianza;
   }

   /**
    * Sets the alianza
    */
   public void setAlianza(String value) {
      this.alianza = value;
   }

   /**
    * Gets the aerolinea
    */
   public String getAerolinea() {
      return this.aerolinea;
   }

   /**
    * Sets the aerolinea
    */
   public void setAerolinea(String value) {
      this.aerolinea = value;
   }
}
