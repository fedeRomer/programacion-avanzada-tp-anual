/**
 * Generated on Sat May 30 21:05:09 UTC 2020 by ObjGen 3.0
 */
package com.tpFinal;

/**
 *
 */
public class Telefono {

   /** Property laboral */
   String laboral;

   /** Property personal */
   String personal;

   /** Property celular */
   String celular;

   /**
    * Gets the laboral
    */
   public String getLaboral() {
      return this.laboral;
   }

   /**
    * Sets the laboral
    */
   public void setLaboral(String value) {
      this.laboral = value;
   }

   /**
    * Gets the personal
    */
   public String getPersonal() {
      return this.personal;
   }

   /**
    * Sets the personal
    */
   public void setPersonal(String value) {
      this.personal = value;
   }

   /**
    * Gets the celular
    */
   public String getCelular() {
      return this.celular;
   }

   /**
    * Sets the celular
    */
   public void setCelular(String value) {
      this.celular = value;
   }
}
