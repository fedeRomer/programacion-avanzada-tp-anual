/**
 * Generated on Sat May 30 21:07:50 UTC 2020 by ObjGen 3.0
 */
package com.tpFinal;

/**
 *
 */
public class Pais {

   /** Property nombre */
   String nombre;

   /** Property provincia */
   String provincia;

   /**
    * Gets the nombre
    */
   public String getNombre() {
      return this.nombre;
   }

   /**
    * Sets the nombre
    */
   public void setNombre(String value) {
      this.nombre = value;
   }

   /**
    * Gets the provincia
    */
   public String getProvincia() {
      return this.provincia;
   }

   /**
    * Sets the provincia
    */
   public void setProvincia(String value) {
      this.provincia = value;
   }
}
