public enum Alianza {
    ALIANZA1("Oneworld"),
    ALIANZA2("SkyTeam"),
    ALIANZA3("Star Alliance");

    public final String alianza;

    private Alianza (String alianza){
        this.alianza = alianza;
    }
}
